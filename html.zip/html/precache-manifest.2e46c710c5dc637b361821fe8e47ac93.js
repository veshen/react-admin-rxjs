self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "990d99ef4dc799079b60935e53d0b632",
    "url": "/index.html"
  },
  {
    "revision": "e526f7a66c9ffda65cbf",
    "url": "/static/css/2.b1dbfd5a.chunk.css"
  },
  {
    "revision": "e526f7a66c9ffda65cbf",
    "url": "/static/js/2.592113aa.chunk.js"
  },
  {
    "revision": "55d9e7a8a68e46944ed2",
    "url": "/static/js/main.50f2c893.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  }
]);